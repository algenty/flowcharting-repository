// eslint-disable-next-line func-names
module.exports = function () {
  __express__.close();
};
