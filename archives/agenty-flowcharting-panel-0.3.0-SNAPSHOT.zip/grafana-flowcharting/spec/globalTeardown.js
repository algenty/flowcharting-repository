import express from 'express';
module.exports = function() {
  __express__.close();
};
