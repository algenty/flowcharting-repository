var plugin = require("../src/plugin.js");
console.log("plugin ", plugin);